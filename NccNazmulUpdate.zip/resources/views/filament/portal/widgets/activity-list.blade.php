<x-filament-widgets::widget>
    <x-filament::section>
        {{$this->table}}
    </x-filament::section>
</x-filament-widgets::widget>
