<h2>Hey {{ $toName }} !</h2> <br><br>

You received an email from : {{ $fromName }} <br><br>


Subject:  {{ $subject }}<br>
Message:  {!! $body !!}<br><br>

Thanks
