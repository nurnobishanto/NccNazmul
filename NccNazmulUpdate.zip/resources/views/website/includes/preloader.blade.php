<div class="onloadpage" id="page_loader">
    <div class="pre-content">
        <div class="logo-pre"><img src="{{asset('uploads/'.getSetting('preloading_image'))}}" alt="Logo" class="img-fluid" /></div>
        <div class="pre-text- text-radius text-light text-animation bg-b">{{getSetting('preloading_text')}}</div>
    </div>
</div>
