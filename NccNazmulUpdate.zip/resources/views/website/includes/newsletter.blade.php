<div class="footer-row1">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="email-subs">
                    <h3>Get New Insights Weekly</h3>
                    <p>News letter dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Enter your email</p>
                </div>
            </div>
            <div class="col-lg-6 v-center">
                <div class="email-subs-form">
                    <form>
                        <input type="email" placeholder="Email Your Address" name="emails">
                        <button type="submit" name="submit" class="lnk btn-main bg-btn">Subscribe <i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
