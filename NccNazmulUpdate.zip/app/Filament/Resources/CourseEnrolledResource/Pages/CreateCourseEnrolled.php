<?php

namespace App\Filament\Resources\CourseEnrolledResource\Pages;

use App\Filament\Resources\CourseEnrolledResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCourseEnrolled extends CreateRecord
{
    protected static string $resource = CourseEnrolledResource::class;
}
