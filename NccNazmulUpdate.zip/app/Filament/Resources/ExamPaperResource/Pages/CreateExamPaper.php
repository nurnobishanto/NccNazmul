<?php

namespace App\Filament\Resources\ExamPaperResource\Pages;

use App\Filament\Resources\ExamPaperResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateExamPaper extends CreateRecord
{
    protected static string $resource = ExamPaperResource::class;
}
